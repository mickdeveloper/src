import { useContext, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "./Contextapi";


function Home() {
    const {name,setName}=useContext(Contextapi)
    const navigate=useNavigate()
    const [data,setData]=useState([])
    const [message,setMessage]=useState('')

    useEffect(()=>{
      fetch('/api/showalluser').then((result)=>{return result.json()}).then((data)=>{ 
        console.log(data)
        if(data.status===200){
          setData(data.apiData)

        }else{
          
setMessage('error')
        }

      })
    },[])

    function handellogout(e){
        window.localStorage.removeItem('name')
        setName(window.localStorage.getItem('name'))
       navigate('/')
    }


    return ( 
        <>
        <nav className="navbar navbar-expand-lg bg-dark">
  <div className="container-fluid">
    <Link className="navbar-brand" to="#"><span className="text-light">Welcome <b className="text-warning">{name}</b></span></Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div className="navbar-nav ms-auto">
        <Link className="nav-link active" aria-current="page" to="/home">Home</Link>
        <Link className="nav-link active" aria-current="page" to="/profile">Profile Update</Link>
  <Link className="nav-link active" aria-current="page" to="/location">Location</Link>
        
        <Link className="nav-link" to="/"><button className="btn btn-danger" onClick={(e)=>{handellogout(e)}}>Logout</button></Link>
       
       
      </div>
    </div>
  </div>
</nav>

<section id="table">
  <table className="table table-info">
    <thead>
      <tr>
        <th>S.no</th>
        <th>Name</th>
        <th>Age</th>
        <th>Location</th>
      </tr>
    </thead>
    <tbody>
     
        {data.map((result,key)=>(
           <tr>
          <td>{key+1}</td>
          <td>{result.name}</td>
          <td>{result.age}</td>
          <td>{result.place}</td>
          </tr>
        ))}
        
     
    </tbody>
  </table>
</section>
        </>
     );
}

export default Home;