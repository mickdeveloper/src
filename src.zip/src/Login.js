import { useContext, useState } from "react";
import {Link, useNavigate} from 'react-router-dom'
import { Contextapi } from "./Contextapi";


function Login() {
    const {name,setName}=useContext(Contextapi)
   // const [name,setName]=useState('')
    const [password,setPassword]=useState('')
    //const [image,setImage]=useState('')
    const [message,setMessage]=useState('')
   
    const navigate=useNavigate()

    function handleform(e){
        e.preventDefault()
        const formdata={name,password}
        //console.log(formdata)
        fetch('/api/',{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((result)=>{return result.json()}).then((data)=>{
            if(data.status===200){
              
                window.localStorage.setItem('name',data.apiData.name)
                setName(window.localStorage.getItem('name'))
                if(data.apiData){
                    navigate('/home')
                }
               
            }else if(data.status===400){
                setMessage('Oops! Worng Username/Password')
                //navigate('/')
                 }
                 else{
                    setMessage('Oops! Worng Username/Password')
                 }
        })
    }

    return ( 
        <>
          <section id="login">
           
    <div className="row">
        <div className="col-md-4"></div>
<div className="col-md-4">
   
    <form onSubmit={(e)=>{handleform(e)}}>
    {message}
        <h2 className="text-center">Login Here</h2>
   <label>name</label>
   <input type="text" className="form-control" value={name} onChange={(e)=>{setName(e.target.value)}} />

   <label>password</label>
   <input type="text" className="form-control" value={password} onChange={(e)=>{setPassword(e.target.value)}} />
   
   <button type="submit" className="form-control btn btn-primary mb-2 mt-2">Login</button>
    </form>
  <Link to='/reg'>don't have account?click here</Link>
</div>
<div className="col-md-4"></div>
    </div>
  </section>
        </>
     );
}

export default Login;