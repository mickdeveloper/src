import { useState } from "react";
import {Link} from 'react-router-dom'


function Reg() {
    const [name,setName]=useState('')
    const [place,setPlace]=useState('')
    const [age,setAge]=useState('')
    const [password,setPassword]=useState('')
    //const [image,setImage]=useState('')
    const [message,setMessage]=useState('')

    function handleform(e){
        e.preventDefault()
        const formdata={name,age,place,password}
        console.log(formdata)
        fetch('/api/reg',{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((result)=>{return result.json()}).then((data)=>{
            if(data.apiData){
                setMessage(data.message)
            }else{
                setMessage(data.message)
            }
        })
    }

    return ( 
        <>
          <section id="login">
            {message}
    <div className="row">
        <div className="col-md-4"></div>
<div className="col-md-4">
   
    <form onSubmit={(e)=>{handleform(e)}}>
        <h2 className="text-center">Register Here</h2>
   <label>name</label>
   <input type="text" className="form-control" value={name} onChange={(e)=>{setName(e.target.value)}} />
   
   <label>age</label>
   <input type="number" className="form-control" value={age} onChange={(e)=>{setAge(e.target.value)}} />
   <label>place</label>
   <input type="text" className="form-control" value={place} onChange={(e)=>{setPlace(e.target.value)}} />
   <label>Create password</label>
   <input type="text" className="form-control" value={password} onChange={(e)=>{setPassword(e.target.value)}} />
   
   <button type="submit" className="form-control btn btn-primary mb-2 mt-2">Register</button>
    </form>
  <Link to='/'>if you have account?click here</Link>
</div>
<div className="col-md-4"></div>
    </div>
  </section>
        </>
     );
}

export default Reg;