import { createContext } from "react";

export const Contextapi= createContext(null)